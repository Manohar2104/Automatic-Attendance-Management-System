package com.automatic.attendance.student.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.Text
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import com.automatic.attendance.student.network.RetrofitClient
import com.automatic.attendance.student.network.AuthApi
import com.automatic.attendance.student.storage.SecureTokenStorageImpl
import com.automatic.attendance.student.repository.AuthRepository
import com.automatic.attendance.student.viewmodel.DashboardViewModel


@Composable
fun DashboardScreen(navController: NavController) {
    val context = LocalContext.current
    val retrofit = RetrofitClient.create("http://localhost:3000")
    val api = retrofit.create(AuthApi::class.java)
    val storage = SecureTokenStorageImpl(context)
    val repo = AuthRepository(api, storage)
    val vm: DashboardViewModel = remember { DashboardViewModel(repo) }

    LaunchedEffect(Unit) { vm.loadProfile() }

    val state = vm.state.collectAsState().value

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (state) {
            is com.automatic.attendance.student.viewmodel.DashboardState.Loading -> CircularProgressIndicator()
            is com.automatic.attendance.student.viewmodel.DashboardState.Error -> Text((state as com.automatic.attendance.student.viewmodel.DashboardState.Error).message)
            is com.automatic.attendance.student.viewmodel.DashboardState.Ready -> {
                val user = (state as com.automatic.attendance.student.viewmodel.DashboardState.Ready).user
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Welcome, ${user.name ?: user.id}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { navController.navigate("active_sessions") }) { Text("View Active Sessions") }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = {
                        // logout
                        LaunchedEffect(Unit) {
                            vm.logout()
                            navController.navigate("login") { popUpTo("dashboard") { inclusive = true } }
                        }
                    }) { Text("Logout") }
                }
            }
            else -> Text("Dashboard")
        }
    }
}
