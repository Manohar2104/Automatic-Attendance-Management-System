package com.automatic.attendance.student.repository

import com.automatic.attendance.student.network.SessionApi
import com.automatic.attendance.student.network.ActiveSession
import retrofit2.Response

class SessionRepository(private val api: SessionApi) {
    suspend fun listActive(): Response<Map<String, List<ActiveSession>>> {
        return api.listActive()
    }

    suspend fun joinSession(sessionId: String, studentId: String): Response<Map<String, Any>> {
        val body = mapOf("studentId" to studentId)
        return api.joinSession(sessionId, body)
    }
}
