package com.automatic.attendance.student.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

data class LoginRequest(val username: String, val password: String)
data class TokenResponse(val accessToken: String, val refreshToken: String)

interface AuthApi {
    @POST("/auth/login")
    suspend fun login(@Body req: LoginRequest): Response<TokenResponse>

    @POST("/auth/refresh")
    suspend fun refresh(@Body body: Map<String, String>): Response<TokenResponse>

    @POST("/auth/logout")
    suspend fun logout(): Response<Unit>

    @GET("/auth/me")
    suspend fun me(): Response<Map<String, Any>>
}

data class ActiveSession(val sessionId: String, val status: String, val startTime: String?)

interface SessionApi {
    @GET("/sessions/active")
    suspend fun listActive(): Response<Map<String, List<ActiveSession>>>

    @POST("/sessions/{id}/join")
    suspend fun joinSession(@Path("id") sessionId: String, @Body body: Map<String, Any>): Response<Map<String, Any>>
}
