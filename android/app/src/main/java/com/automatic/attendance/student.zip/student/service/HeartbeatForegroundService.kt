package com.automatic.attendance.student.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.automatic.attendance.student.R
import com.automatic.attendance.student.wifi.WifiScanManager
import com.automatic.attendance.student.repository.HeartbeatRepository
import com.automatic.attendance.student.repository.HeartbeatPayload
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant

class HeartbeatForegroundService : Service() {
    private val binder = HeartbeatBinder()
    private var sessionId: String? = null
    private var studentId: String? = null
    private lateinit var wifiManager: WifiScanManager
    private lateinit var repo: HeartbeatRepository
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO)

    private var isRunning = false
    private val HEARTBEAT_INTERVAL_MS = 15000L // 15 seconds

    inner class HeartbeatBinder : Binder() {
        fun getService(): HeartbeatForegroundService = this@HeartbeatForegroundService
    }

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sessionId = intent?.getStringExtra("sessionId")
        studentId = intent?.getStringExtra("studentId")

        if (!sessionId.isNullOrEmpty() && !studentId.isNullOrEmpty()) {
            startHeartbeats()
        }

        return START_STICKY
    }

    private fun startHeartbeats() {
        if (isRunning) return
        isRunning = true

        // Show notification
        val notification = NotificationCompat.Builder(this, "heartbeat_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Attendance Service")
            .setContentText("Monitoring attendance...")
            .build()

        startForeground(1, notification)

        // Start heartbeat loop
        sendHeartbeat()
    }

    private fun sendHeartbeat() {
        if (!isRunning) return

        scope.launch {
            try {
                val fingerprint = wifiManager.getWifiFingerprint()
                val seq = repo.getNextSequenceNumber()
                val payload = HeartbeatPayload(
                    sessionId = sessionId ?: "",
                    wifiFingerprint = fingerprint,
                    sequenceNumber = seq,
                    deviceFingerprint = android.os.Build.FINGERPRINT,
                    timestamp = Instant.now().toString()
                )

                val resp = repo.sendHeartbeat(payload)
                // Handle response: success, replay rejection, session closed, network failures
            } catch (e: Exception) {
                // Log error
            }
        }

        handler.postDelayed({ sendHeartbeat() }, HEARTBEAT_INTERVAL_MS)
    }

    fun stopHeartbeats() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        repo.resetSequence()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopHeartbeats()
        super.onDestroy()
    }
}
